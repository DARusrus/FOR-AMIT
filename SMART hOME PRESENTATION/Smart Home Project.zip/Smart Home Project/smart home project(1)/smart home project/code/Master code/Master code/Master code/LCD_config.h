/*
 * LCD_config.h
 *
 *
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_

#define eight_bits_mode
//#define four_bits_mode

#endif /* LCD_CONFIG_H_ */